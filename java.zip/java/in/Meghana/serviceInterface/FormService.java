package in.Meghana.serviceInterface;

import in.Meghana.entity.Form;

public interface FormService {

	int save(Form form);

}
