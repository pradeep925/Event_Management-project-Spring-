package in.Meghana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventManagementSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventManagementSpringProjectApplication.class, args);
	}

}
